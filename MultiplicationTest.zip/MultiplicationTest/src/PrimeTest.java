import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PrimeTest {

    @Test
    void isPrime(){
        assertTrue(Main.IsPrime(12), "11 should be prime");
    }

}
